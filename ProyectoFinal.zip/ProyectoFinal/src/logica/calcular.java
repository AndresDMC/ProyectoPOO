package logica;

public interface calcular {
	
	double calcular();

}
