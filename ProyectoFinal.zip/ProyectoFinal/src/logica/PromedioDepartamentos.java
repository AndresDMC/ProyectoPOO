package logica;

import java.io.BufferedReader;

import java.io.FileReader;
import java.io.IOException;
import java.util.Arrays;

public class PromedioDepartamentos implements calcular{
	 private String linea;
     private int numMeses = 0;
     private int numDepartamentos = 0;
     private double[] totales = null;
     private String datos_orga;
     
     
	public double calcular() {
		String archivo = "datos.txt";
		try (BufferedReader br = new BufferedReader(new FileReader(archivo))) {
           

            // Leer la primera línea para obtener el número de meses
            linea = br.readLine();
            String[] meses = linea.split(",");
            numMeses = meses.length - 1;

            // Leer las líneas restantes y procesar los datos
            String[] departamentos = new String[100]; // Se asume un máximo de 100 departamentos
            totales = new double[100];
            while ((linea = br.readLine()) != null) {
                String[] elementos = linea.split(",");
                departamentos[numDepartamentos] = elementos[0];
                for (int i = 1; i <= numMeses; i++) {
                    totales[numDepartamentos] += Double.parseDouble(elementos[i]);
                }
                numDepartamentos++;
            }

            // Calcular el promedio de cada departamento
            double promedioTotal = 0;
            for (int i = 0; i < numDepartamentos; i++) {
                double promedioDepartamento = totales[i] / numMeses;
                promedioTotal += promedioDepartamento;
                datos_orga=datos_orga+"Promedio Departamento " + departamentos[i] + ": " + promedioDepartamento+"\n";
            }

            // Calcular el promedio total
            promedioTotal /= numDepartamentos;
            datos_orga=datos_orga+"Promedio Total de todos los departamentos: " + promedioTotal;

        } catch (IOException e1) {
            e1.printStackTrace();
        }
		return 0;
    }
}